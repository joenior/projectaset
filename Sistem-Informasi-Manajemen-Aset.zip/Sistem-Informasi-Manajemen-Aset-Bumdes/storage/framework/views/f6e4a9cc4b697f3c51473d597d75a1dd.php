<?php $__env->startSection('content'); ?>
    <h1 class="h3 mb-4">Data Permintaan Pengadaan barang</h1>

    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="table_id" class="display">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Pengajuan</th>
                                    <th>Status</th>
                                    <th>Detail</th>
                                    <th>Opsi</th>   
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $permintaans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permintaan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>                      
                                        <td><?php echo e($permintaan->nama_pengadaan); ?></td>
                                        <td>
                                            <?php if($permintaan->status == 'pending'): ?>
                                                <span class="badge bg-warning text-dark"><?php echo e($permintaan->status); ?></span>
                                            <?php elseif($permintaan->status == 'disetujui'): ?>
                                                <span class="badge bg-success"><?php echo e($permintaan->status); ?></span>
                                            <?php else: ?>
                                                <span class="badge bg-danger"><?php echo e($permintaan->status); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="/permintaan/<?php echo e($permintaan->id); ?>" class="btn btn-secondary d-inline mb-2"><i class="bi bi-eye-fill"></i></a>
                                        </td>
                                        <td>
                                            <?php if($permintaan->status == 'pending'): ?>
                                                <form id="form-<?php echo e($permintaan->id); ?>"  action="/permintaan/<?php echo e($permintaan->id); ?>/setuju" method="POST" class="d-inline">
                                                    <?php echo method_field('PUT'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <div class="btn btn-success mb-2 pengajuan-confirm" data-form="form-<?php echo e($permintaan->id); ?>"><i class="bi bi-check-square"></i></div>
                                                </form>
                                                <form id="form-<?php echo e($permintaan->id); ?>-tolak" action="/permintaan/<?php echo e($permintaan->id); ?>/tolak" method="POST" class="d-inline">
                                                    <?php echo method_field('PUT'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <div class="btn btn-danger mb-2 tolak-confirm" data-form="form-<?php echo e($permintaan->id); ?>-tolak"><i class="bi bi-x-square"></i></div>
                                                </form>
                                            <?php else: ?>
                                                <a href="/permintaan/<?php echo e($permintaan->id); ?>/edit" class="btn btn-primary d-inline mb-2"><i class="bi bi-plus-square-fill"></i> Kirim Catatan</a>
                                            <?php endif; ?>
                                            <a class="btn btn-primary" href="/permintaan/laporan-pengadaan/<?php echo e($permintaan->id); ?>" target="_blank" Roles="button"><i class="bi bi-printer"></i>&nbsp; Cetak</a>                    
                                        </td>
                                    </tr>  
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                     
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready( function () {
            $('#table_id').DataTable();
        });
    </script>

    <script>
        $(document).ready(function(){
            $('.pengajuan-confirm, .tolak-confirm').click(function(event){
                event.preventDefault();
                var formId = $(this).attr('data-form');
                document.getElementById(formId).submit();
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/xyzarco/Sistem-Informasi-Manajemen-Aset-Bumdes/resources/views/permintaan/index.blade.php ENDPATH**/ ?>