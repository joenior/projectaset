<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6">
            <h1 class="h3 mb-4">Laporan keuangan</h1>
        </div>
        <div class="col-md-6">
             <a class="btn btn-primary my-2 me-2 float-end" href="/keuangan/laporan-keuangan" target="_blank" Roles="button"><i class="bi bi-printer"></i>&nbsp; Cetak</a>                    
        </div>
    </div>
    
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="table_id" class="display">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Kode Barang</th>
                                    <th>Nama Barang</th>
                                    <th>Harga</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $hargaBarangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $harga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($harga->kode_barang); ?></td>
                                        <td><?php echo e($harga->nama); ?></td>
                                        <td>Rp. <?php echo e(number_format($harga->harga, 2, ',', '.')); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="3"><strong>Total Harga</strong></td>
                                    <td><strong>Rp. <?php echo e(number_format($totalHarga, 2, ',', '.')); ?></strong></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
    

    <script>
        $(document).ready( function () {
            var table = $('#table_id').DataTable({
                "drawCallback": function( settings ) {
                    var api = this.api();
                    var total = api.column(3).data().reduce(function(acc, val) {
                        var harga = parseFloat(val.replace(/[^0-9.-]+/g,""));
                        return acc + harga;
                    }, 0);
                    $('#total-harga').html('Total Harga: Rp. '+ total);
                }
            });
        });
    </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/xyzarco/Sistem-Informasi-Manajemen-Aset-Bumdes/resources/views/keuangan/index.blade.php ENDPATH**/ ?>