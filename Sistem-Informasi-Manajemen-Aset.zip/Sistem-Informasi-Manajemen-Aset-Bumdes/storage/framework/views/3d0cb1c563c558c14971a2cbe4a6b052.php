<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="authentication-wrapper authentication-basic container-p-y">
      <div class="authentication-inner">
      
        <div class="card">
          <div class="card-body">

            <h4 class="my-4" style="text-align: center">SISTEM INFORMASI MANAJEMEN ASET</h4>

            <form action="<?php echo e(route('login')); ?>" method="POST" class="mb-3">
              <?php echo csrf_field(); ?>

              <div class="mb-3">
                <label for="email" class="form-label">Masukkan Email</label>
                <input type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" name="email" autofocus/>
              
                  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="invalid-feedback" Roles="alert">
                          <p><?php echo e($message); ?></p>
                      </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              <div class="mb-3 form-password-toggle">
                  <div class="d-flex justify-content-between">
                  <label class="form-label" for="password">Masukkan Password</label>
              </div>
                <div class="input-group input-group-merge">
                  <input type="password" id="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" aria-describedby="password"/>
                  <span class="input-group-text cursor-pointer"><i class="bx bx-hide"></i></span>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" Roles="alert">
                            <p><?php echo e($message); ?></p>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              <div class="mb-3">
                <button class="btn btn-primary d-grid w-100" type="submit">Masuk</button>
              </div>
            </form>

            <p class="text-center">
                <span>Lupa Kata Sandi ?</span>
                <span>Segera Hubungi Admin</span>
            </p>
          </div>
        </div>

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
    

   

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/xyzarco/Sistem-Informasi-Manajemen-Aset-Bumdes/resources/views/auth/login.blade.php ENDPATH**/ ?>