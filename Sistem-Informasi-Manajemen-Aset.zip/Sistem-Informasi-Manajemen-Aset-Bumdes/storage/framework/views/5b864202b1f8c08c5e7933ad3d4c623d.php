<?php $__env->startSection('content'); ?>
    <h1 class="h3 mb-4">Riwayat Penghapusan Aset</h1>
    
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="table_id" class="display">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Gambar Barang</th>
                                    <th>Kode Barang</th>
                                    <th>Nama Barang</th>
                                    <th>Lokasi</th>
                                    <th>Tanggal Dihapus</th>
                                    <th>Opsi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $deletedBarangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><img src="<?php echo e(asset('storage/'. $barang->gambar)); ?>" alt="gambar barang" style="width: 150px"; height="150px"></td>
                                        <td><?php echo e($barang->kode_barang); ?></td>
                                        <td><?php echo e($barang->nama); ?></td>
                                        <td><?php echo e($barang->lokasi->nama_lokasi); ?></td>
                                        <td><?php echo e($barang->deleted_at); ?></td>
                                        <td>
                                            <form action="/penghapusan-aset/restore/<?php echo e($barang->id); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <button type="submit" class="btn btn-primary my-1"><i class="bi bi-arrow-repeat"></i> Kembalikan </button>
                                            </form>

                                            <form id="<?php echo e($barang->id); ?>" action="/penghapusan-aset/<?php echo e($barang->id); ?>" method="POST" class="d-inline">
                                                <?php echo method_field('delete'); ?>
                                                <?php echo csrf_field(); ?>
                                                <div class="btn btn-danger mb-2 swal-confirm" data-form="<?php echo e($barang->id); ?>"><i class="bi bi-trash-fill"></i> Permanen</div>
                                            </form>
                                        </td>
                                    </tr>  
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                     
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready( function () {
        $('#table_id').DataTable();
    } );
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/xyzarco/Sistem-Informasi-Manajemen-Aset-Bumdes/resources/views/penghapusan-aset/index.blade.php ENDPATH**/ ?>