<?php $__env->startSection('content'); ?>
    <h1 class="h3 mb-4">Cetak Laporan</h1>
    
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">

                        <div class="form-group">
                            <form id="cetak-form" method="GET" action="<?php echo e(route('cetak')); ?>" target="_blank" onsubmit="return validateForm()">

                                <div class="row my-3">
                                    <div class="col-md-3">
                                        <label for="tgl-mulai" class="form-label">Tanggal Mulai</label>
                                        <input type="date" id="tgl-mulai" name="tgl_mulai" class="form-control">
                                    </div>
                                    <div class="col-md-3">
                                        <label for="tgl-selesai" class="form-label">Tanggal Selesai</label>
                                        <input type="date" id="tgl-selesai" name="tgl_selesai" class="form-control">
                                    </div>
                                    <div class="col">
                                        <button type="submit" class="btn btn-primary float-end"> <i class="bi bi-printer"></i> Cetak </button>
                                    </div>
                                </div>

                              
                             </form>
                        </div>
                              
                        <table id="table_id" class="display">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Kode Barang</th>
                                    <th>Nama Barang</th>
                                    <th>Kategori</th>
                                    <th>Lokasi</th>
                                    <th>Tgl. Upload</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $laporans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laporan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>             
                                        <td><?php echo e($laporan->kode_barang); ?></td>
                                        <td><?php echo e($laporan->nama); ?></td>
                                        <td><?php echo e($laporan->kategori->nama); ?></td>
                                        <td><?php echo e($laporan->lokasi->nama_lokasi); ?></td>
                                        <td><?php echo e($laporan->tanggal); ?></td>
                                    </tr>  
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                     
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            var table = $('#table_id').DataTable({
                "order": [[5, "asc"]]
            });

            $('#tanggal-mulai, #tanggal-selesai').change(function() {
                var tanggalMulai = $('#tanggal-mulai').val();
                var tanggalSelesai = $('#tanggal-selesai').val();
                table.columns(5).search('').draw();
                table.columns(5).search(tanggalMulai + ' - ' + tanggalSelesai).draw();
            });
        });
   </script>
   
   <script>
        function validateForm() {
        var tglMulai = document.getElementById("tgl-mulai").value;
        var tglSelesai = document.getElementById("tgl-selesai").value;

        if (!tglMulai || !tglSelesai) {
            Swal.fire(
                'Ooppss',
                'Harap Masukan Kolom Tanggal Mulai Dan Selesai Terlebih Dahulu',
                'warning'
            )
            return false;
        }
        return true;
    }
   </script>
       
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/xyzarco/Sistem-Informasi-Manajemen-Aset-Bumdes/resources/views/laporan/index.blade.php ENDPATH**/ ?>